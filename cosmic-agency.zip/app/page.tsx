"use client"

import Page from "../page"

export default function SyntheticV0PageForDeployment() {
  return <Page />
}